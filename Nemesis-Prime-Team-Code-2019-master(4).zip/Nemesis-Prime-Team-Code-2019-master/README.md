# Nemesis-Prime-Team-Code-2019
hello! this is the FTC14020 teamcode for the rover ruckus season kek

mannan shukla
nick walls
geethika manojkumar
jeremy murray
